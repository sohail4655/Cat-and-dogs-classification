data = []
c = 0
for files in os.listdir("C:\\Users\\ADMIN\\Desktop\\Machine learning\\Datasets\\train\\train"):
    c += 1
print(c)
for files in os.listdir("C:\\Users\\ADMIN\\Desktop\\Machine learning\\Datasets\\train\\train"):
    image = cv2.resize(cv2.imread(os.path.join("C:\\Users\\ADMIN\\Desktop\\Machine learning\\Datasets\\train\\train", files)), (100, 100))
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    label = files.split('.')[0]
    if label == 'cat':
        data.append([gray, np.array([0, 1])])
    elif label == 'dog':
        data.append([gray, np.array([1, 0])])

train , test = train_test_split(data, test_size = 0.1, shuffle = True)
X = np.array([i[0] for i in train]).reshape(-1, 100, 100, 1)
Y = np.array([i[1] for i in train])
x_valid = np.array([i[0] for i in test]).reshape(-1, 100, 100, 1)
y_valid = np.array([i[1] for i in test])
X = X.astype('float32')/255
x_valid = x_valid.astype('float32')/255
model = Sequential()
model.add(Conv2D(64, (3, 3), activation='relu', input_shape=(100, 100, 1), padding='same'))
model.add(Conv2D(64, (3, 3), activation='relu'))
model.add(MaxPooling2D((2,2)))
model.add(Conv2D(64, (3, 3), activation='relu'))
model.add(MaxPooling2D((2,2)))
model.add(Conv2D(32, (3, 3), activation='relu'))
model.add(MaxPooling2D((2,2)))
model.add(Conv2D(32, (3, 3), activation='relu'))
model.add(MaxPooling2D((2,2)))
model.add(Conv2D(32, (3, 3), activation='relu'))
model.add(MaxPooling2D((2,2)))

model.add(Flatten())
model.add(Dense(512, activation='relu'))
model.add(Dense(2, activation='sigmoid'))


opt = tf.keras.optimizers.Adam(learning_rate=0.0001)
model.compile(loss= 'categorical_crossentropy', optimizer= opt, metrics=['accuracy'])
model.fit(X, Y, batch_size= 10, epochs= 3, verbose= 1, validation_data=(x_valid,y_valid))
model.evaluate(x_valid,y_valid)
pred=model.predict(x_valid)
print("predictions",pred)
print("original",y_valid)